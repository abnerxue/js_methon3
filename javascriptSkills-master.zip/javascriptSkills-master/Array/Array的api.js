1.push pop
2.shift unshift
3.join cancat
4.reverse
5.slice
6.splice
7.sort

Ecma5添加的新方法

8.map forEach
9.filter
10.some every
11.reduce  reduceRight
12.indexOf lastIndexOf
