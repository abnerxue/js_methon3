for in 可以获取包含对象原型上的属性名称！
Object.keys() 可以获取对象本身的属性名称（不包含可枚举属性，如Array的length属性）！
Object.getOwnPropertyNames()可以获取对象本身的属性名称，包含不可枚举属性！
