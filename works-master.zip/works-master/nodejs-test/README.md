# nodejs-test

## 后台启动应用

`node server.js 8888 >! log 2>&1 &`

## 启动应用

`node server.js 8888`

或者

`node server 8888`

## 添加路由

1. 打开 server.js，添加 if else
2. 重新运行 node server.js 8888

