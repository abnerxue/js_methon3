function toNum(strNum){
	return +strNum;
}