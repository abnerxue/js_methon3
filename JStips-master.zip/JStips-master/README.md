# JStips
原生js小技巧


* [01 - 斐波那契数列第n个数的值](https://github.com/HecateDK/JStips/tree/master/example/01-test.html)
* [02 - 使用+将字符串转换成数字](https://github.com/HecateDK/JStips/tree/master/example/02-test.html)
* [03 - 原生js实现jQuery的一些小功能](https://github.com/HecateDK/JStips/tree/master/example/03-test.html)
* [04 - 使用原生JS实现jQuery的addClass, removeClass, hasClass函数功能](https://github.com/HecateDK/JStips/tree/master/example/04-test.html)
* [05 - 原生js实现jQuery事件代理（未完善）](https://github.com/HecateDK/JStips/tree/master/example/05-test.html)
* [06 - 几个简单的正则表达式（未完善）](https://github.com/HecateDK/JStips/tree/master/example/06-test.html)
* [07 - js实现身份证验证](https://github.com/HecateDK/JStips/tree/master/example/07-test.html)
* [08 - js反转字符串](https://github.com/HecateDK/JStips/issues/1)
* [09 - 3个有用的数组技巧](https://github.com/HecateDK/JStips/issues/2)
* [09 - 跨浏览器事件处理](https://github.com/HecateDK/JStips/issues/3)
