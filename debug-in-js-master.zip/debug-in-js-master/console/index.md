# Console

平常开发中，经常会使用consoel.log、console.warn、console.error等打印信息的功能以外，在Chrome中还有些其它骚操作

## 1. console.table

## 2. console.assert

## 3. console.count

## 4. console.profile

## 5. console.trace

## 6. console.time
