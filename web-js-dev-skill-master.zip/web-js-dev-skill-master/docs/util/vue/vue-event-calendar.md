# Vue 手机端日历组件

## 使用项目

+ [zn-sign](https://gitee.com/weblife/zj-zn-sign/tree/master/src/components/vue-event-calendar)

## 参考资料