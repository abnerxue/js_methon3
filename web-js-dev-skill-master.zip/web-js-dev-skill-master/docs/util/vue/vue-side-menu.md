# Vue SideMenu 组件

> 手机端侧边栏收缩菜单.

## 项目

+ [gggjxtd](https://gitee.com/weblife/gdgjxtd-house/blob/master/src/components/slidemenu/index_diy.vue)