# 浏览器全屏解决方案

## 参考资料

+ [screenfull.js](https://www.npmjs.com/package/screenfull)