# 事件处理

> JS 的一道坎就是事件的处理，那么如何自定义事件，如何处理事件呢，这篇主要讲解事件的监听、派发与移除的封装


## 不依赖 dom 的事件处理

+ [点我查看](docs/function-skill/EventEmitter)
